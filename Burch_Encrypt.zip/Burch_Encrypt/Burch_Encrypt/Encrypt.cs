﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Burch_Encrypt
{
    class Encrypt
    {
        static void Main(string[] args)//main method as an array//
        {
            Console.Write("Enter Whole four digit Number: ");// asks user for input//

            try
            {
                int userInput = int.Parse(Console.ReadLine());//parses the user input and stores it in the variable//

                int digit1 = ((userInput / 1000) + 7) % 10; //userinput is used in the expression and its result is assigned to digit1//
                int digit2 = ((userInput / 100) + 7) % 10;// "" //
                int digit3 = ((userInput / 10) + 7) % 10;// "" //
                int digit4 = ((userInput % 10) + 7) % 10;// "" //

                string output = "" + digit3 + digit4 + digit1 + digit2;//mixes digits//

                Console.Write("The encrypted output is: " + output); // returns the encrypted output to the user //

            }
            catch (Exception)
            {
                Console.Write("User Input is in incorrect format");//corrects user input format//
            }
            Console.ReadKey();//waits for user to press any key//
            
        }
        
    }
}
